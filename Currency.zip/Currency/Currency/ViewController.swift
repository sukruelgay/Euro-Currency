//
//  ViewController.swift
//  Currency
//
//  Created by Sukru on 2.01.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var cadolar: UILabel!
    @IBOutlet weak var dolar: UILabel!
    @IBOutlet weak var lira: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getcurrencydata()
    }

func getcurrencydata()
{
    let url = URL(string: "http://data.fixer.io/api/latest?access_key=521ac4d4b9d77aecdc87e8237e66fe68&format=1")
    
    
    let session = URLSession.shared
    let task = session.dataTask(with: url!) { (data, response, error) in
        if error != nil {
            print(error?.localizedDescription)
        }
        else {
            
            if data != nil {
                do {
                    let jsonresponse = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! Dictionary<String,Any>
                    DispatchQueue.main.async {
                       // print(jsonresponse)
                        
                        if let kur = jsonresponse["rates"] as? [String:Any] {
                            //print(kur)
                        
                        if let turk = kur["TRY"] as? Double {
                            self.lira.text = "TRY: \(turk)"
                            
                        }
                            
                            if let dolar = kur["USD"] as? Double {
                                self.dolar.text = "USD: \(dolar)"
                            }
                            if let cad = kur["CAD"] as? Double {
                                self.cadolar.text = "CAD: \(cad)"
                            }
                    }
                    }
                } catch  {
                    
                }
            }
        }
        
    }
    task.resume()
}
    @IBAction func renew(_ sender: Any) {
        
        getcurrencydata()
    }
    
}

