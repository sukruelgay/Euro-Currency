//
//  AuthScreen.swift
//  Currency
//
//  Created by Sukru on 2.01.2021.
//

import UIKit
import FirebaseAuth

class AuthScreen: UIViewController {

    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var email: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    

    @IBAction func signup(_ sender: Any) {
        Auth.auth().createUser(withEmail: email.text!, password: password.text!) { authResult, error in
            if error == nil {
                self.performSegue(withIdentifier: "ok", sender: nil)
            }
            else {
                print(error?.localizedDescription)
            }
        }
    }
    
    @IBAction func signin(_ sender: Any) {
        
        Auth.auth().signIn(withEmail: email.text!, password: password.text!) { [weak self] authResult, error in
          guard let strongSelf = self else { return }
            if error == nil {
                self?.performSegue(withIdentifier: "ok", sender: nil)
            }
            else {
                print(error?.localizedDescription)
            }
        }
    }
    
}
